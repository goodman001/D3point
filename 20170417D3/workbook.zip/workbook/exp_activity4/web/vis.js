"use strict";

/* Boilerplate jQuery */
$(function() {
  d3.csv("res/CSplusX.csv", function (data) {
    visualize(data);
  });
});

/* Visualize the data in the visualize function */
var visualize = function(data) {
  console.log(data);

  // == BOILERPLATE ==
  var margin = { top: 50, right: 50, bottom: 50, left: 50 },
     width = 900 - margin.left - margin.right,
     height = 930 - margin.top - margin.left;

  var svg = d3.select("#chart")
              .append("svg")
              .attr("width", width + margin.left + margin.right)
              .attr("height", height + margin.top + margin.bottom)
              .style("width", width + margin.left + margin.right)
              .style("height", height + margin.top + margin.bottom)
              .append("g")
              .attr("transform", "translate(" + margin.left + "," + margin.top + ")");
  


  // == Your code! :) ==
  svg.attr("transform", "translate(" + width / 2 + "," + height / 2 + ")");

  var radius = Math.min(width, height) /2.8;
  var color = d3.scaleOrdinal(d3.schemeCategory20);
  var arc = d3.arc()
    .outerRadius(radius - 10)
    .innerRadius(radius - 80);
  var pie = d3.pie()
    .sort(null)
    .value(function(d) { return d.Total; });
  var g = svg.selectAll(".arc")
      .data(pie(data))
    .enter().append("g");

  g.append("path")
      .attr("d", arc)
      .style("fill", function(d) { return color(d.data.Degree); });

  g.append("text")
      .attr("transform", function(d) {
        var _d = arc.centroid(d);
        _d[0] *= 1.3; //multiply by a constant factor
        _d[1] *= 1.2; //multiply by a constant factor
        return "translate(" + _d + ")";
      })
      .attr("dy", ".10em")
      .style("text-anchor", "middle")
      .style("font", "6px sans-serif")
      .text(function(d) { return d.data.Degree + ": "+d.data.Total ; });
  svg.append("text")
  .attr("x", 0)
  .attr("y", 0)
  .attr("text-anchor", "middle")
  .attr("font-family", "sans-serif")
  .attr("font-size", "20px")
  .attr("font-weight", "bold")
  .text("Degree-Total-Donut chart");
};
