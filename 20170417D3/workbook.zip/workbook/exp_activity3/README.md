# CS 296 Workbook

This folder is the base of the CS 296-25 workbook, where nearly all of your
work for CS 296-25 will reside.
